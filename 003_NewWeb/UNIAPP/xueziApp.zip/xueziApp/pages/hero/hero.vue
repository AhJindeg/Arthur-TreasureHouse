<template>
	<!-- <view style="display: flex;"> -->
	<!-- 案例: 侧边栏导航切换  -->
	<!-- 发请求=>拿数据=>存本地=>做展示 -->
	<!-- 左侧菜单 -->
	<!-- windowHeight 窗口高度 -->
	<!-- <scroll-view
			scroll-y
			style="width: 30%;"
			:style="{ height: windowHeight + 'px' }"
		> -->
	<!-- 动态绑定的class cur 后面的表达式为真生效   遍历到的下标正好是当前选项项  就绑定cur高亮效果  -->
	<!-- <view
				v-for="(item, index) in menu"
				:key="index"
				class="menu-cell"
				:class="{ cur: index == current }"
				@click="doCheck(index)"
			>
				{{ item.catalog }}
			</view>
		</scroll-view> -->
	<!-- 右侧图书详情 -->
	<!-- showRight 默认渲染 展示  给true -->
	<!-- <scroll-view
			v-if="showRight"
			scroll-y
			style="width: 70%;"
			:style="{ height: windowHeight + 'px' }"
		> -->
	<!-- 折叠面板 -->
	<!-- <uni-collapse>
				<uni-collapse-item
					v-for="(item, index) in books"
					:key="index"
					:title="item.title"
					:thumb="item.img"
				> -->
	<!-- 折叠栏里面的图书信息 -->
	<!-- <view>
						<view>{{ item.sub1 }}</view>
						<view>{{ item.reading }}</view>
						<view>{{ item.bytime }}</view>
						<view>{{ item.sub2 }}</view>
					</view>
				</uni-collapse-item>
			</uni-collapse>
		</scroll-view>
	</view> -->
</template>

<script>
export default {
	data() {
		return {
			// 当前选中的菜单项的 下标
			current: 0,
			// 英雄列表数据
			heroList: null,
			// 英雄详情
			heroInfo: null,
			// 右侧是否显示的状态控制
			showRight: true
		};
	},
	mounted() {
		// 英雄列表
		this.getHeros();
	},
	methods: {
		// 获取英雄列表
		getHeros() {
			const url =
				'https://game.gtimg.cn/images/lol/act/img/js/heroList/hero_list.js?v=50';
			uni.request({
				url,
				method: 'GET',
				data: {},
				success: res => {
					console.log(res);
					// this.heroList = res.data.result.data;
					// // 图书数据加载完毕  先移除右侧显示  再设置显示
					// this.showRight = false;
					// // 当监听页面渲染完毕时 再显示出来
					// // $nextTick 监听页面渲染完毕 做的操作
					// // 箭头this保持的 不丢失
					// this.$nextTick(()=>{
					// 	this.showRight = true
					// })
				},
				fail: (err) => {
					console.log(err);
				},
				complete: () => {}
			});
		},
		// 切换菜单
		doCheck(index) {
			this.current = index;
			// 每切换菜单 就加载对应分类下的数据
			console.log(this.menu[index].id);
			this.getBooks(this.menu[index].id);
		},
		// 获取左侧菜单数据
		getMenu() {
			const url =
				'/juhe/goodbook/catalog?key=2520f6a5cab03af7e23013b15842d7fc';
			// ureq快捷
			uni.request({
				// url: url,
				url,
				method: 'GET',
				data: {},
				success: res => {
					console.log(res);
					this.menu = res.data.result;
					// 默认请求第一项
					this.getBooks(this.menu[0].id);
				},
				fail: () => {},
				complete: () => {}
			});
		}
	},
	// 计算属性
	computed: {
		windowHeight() {
			console.log(uni.getSystemInfoSync().windowHeight);
			return uni.getSystemInfoSync().windowHeight;
		}
	}
};
</script>

<style scoped lang="scss">
.menu-cell {
	padding-top: 15rpx;
	background-color: #eeeeee;
	border-bottom: 1px solid gray;
	text-align: center;
	// 选中高亮
	// & 当前选择器
	&.cur {
		background-color: orange;
		color: #007aff;
		font-size: 1.1em;
		font-weight: bold;
	}
}
</style>
