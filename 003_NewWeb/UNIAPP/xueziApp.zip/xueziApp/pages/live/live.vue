<template>
	<view>
		<uni-collapse v-if="tags">
			<uni-collapse-item :title="tags[current].cate_name" open>
				<uni-tag
					style="margin: 10rpx;display: inline-block;"
					:text="item.cate_name"
					type="warning"
					:inverted="current == index ? false : true"
					v-for="(item, index) in tags"
					:key="index"
					@click="doCheck(index)"
				></uni-tag>
			</uni-collapse-item>
		</uni-collapse>
		<!-- 分类显示 -->
		<uni-grid
			:column="3"
			:showBorder="false"
			:highlight="false"
			:square="false"
		>
			<uni-grid-item v-for="(item, index) in cate" :key="index">
				<view @click="gotoRooms(index)">
					<image
						:src="item.pic_name"
						style="width: 100%;height:300rpx"
					></image>
					<view>{{ item.tag_name }}</view>
				</view>
			</uni-grid-item>
		</uni-grid>
	</view>
</template>

<script>
export default {
	data() {
		return {
			tags: null,
			current: 0,
			cate: null
		};
	},
	mounted() {
		this.getTags();
	},
	methods: {
		// 前往直播房间列表页面
		gotoRooms(index) {
			// console.log('去房间列表');
			console.log(this.cate);
			const { short_name, tag_name } = this.cate[index];
			console.log(short_name,tag_name);
			// 路由跳转带传参
			uni.navigateTo({
				// https://m.douyu.com/api/room/list?page=1&type=LOL
				url: `/pages/rooms/rooms?type=${short_name}&cate_name=${tag_name}`
			});
		},
		// 切换标签
		doCheck(index) {
			this.current = index;
			console.log(this.tags[index]);
			const { short_name, cate_name } = this.tags[index];
			// console.log(cate_name);
			// 修改折叠栏上面的文字
			this.curruent_catename = cate_name;
			// console.log(this.tags[index]);
			// 分类切换之后需要获取分类数据
			// #ifdef H5
			const url = '/capi/api/v1/getColumnDetail?shortName=' + short_name;
			// #endif
			// #ifndef H5
			const url =
				'http://capi.douyucdn.cn/api/v1/getColumnDetail?shortName=' +
				short_name;
			// console.log(url);
			// #endif
			uni.request({
				url,
				method: 'GET',
				data: {},
				success: res => {
					console.log(res);
					this.cate = res.data.data;
				},
				fail: () => {},
				complete: () => {}
			});
		},
		// 获取分类标签数据
		getTags() {
			// #ifndef H5
			const url = 'http://capi.douyucdn.cn/api/v1/getColumnList';
			// #endif
			// #ifdef H5
			const url = '/capi/api/v1/getColumnList';
			// #endif
			uni.request({
				url,
				method: 'GET',
				data: {},
				success: res => {
					console.log(res);
					this.tags = res.data.data;
				},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
