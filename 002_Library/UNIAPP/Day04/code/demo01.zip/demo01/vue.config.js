// vue.config.js  文件名称  在项目包的根路径下
// 导出模块
module.exports = {
	// 配置开发服务器
	devServer: {
		// 代理
		proxy: {
			// 源地址:https://m.douyu.com/api/room/list?page=1&type=yz
			// 接口编写的地址: /douyu/api/room/list?page=1&type=yz
			// 代理段
			"/douyu": {
				// 代理的域名地址
				target: "https://m.douyu.com",
				// 域名是否有变更  本地服务器localhost  m.douyu.com
				// true 代表域名不一致  大部分情况都是不一样的
				changeOrigin: true,
				// 协议http配置为false默认       https协议配置为true
				secure: true,
				// 路径重写
				pathRewrite: {
					// ^ 正则 ^xxx  xxx开头的
					"^/douyu": ""
				}
			}
		}
	}
}
