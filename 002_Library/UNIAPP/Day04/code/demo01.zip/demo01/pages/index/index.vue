<template>
	<view>
		<!-- utag 标签 -->
		<uni-tag text="皮卡丘" type="default"></uni-tag>
		<uni-tag text="雷丘" type="error"></uni-tag>
		<uni-tag text="杰尼龟" type="primary"></uni-tag>
		<uni-tag text="后羿" type="success" @click="say"></uni-tag>
		<uni-tag text="钟无艳" type="warning"></uni-tag>
		<uni-tag text="圣枪游侠" type="warning" inverted></uni-tag>
		<uni-tag text="亮亮" type="warning" circle></uni-tag>
	</view>
</template>

<script>
	export default {
		methods: {
			say() {
				alert('red buff give me!')
			}
		},
	}
</script>

<style scoped>

</style>