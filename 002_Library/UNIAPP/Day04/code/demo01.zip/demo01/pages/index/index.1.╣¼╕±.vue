<template>
	<view>
		<!-- ugrid -->
		<!-- 属性的值为非字符串  需要绑定属性: -->
		<uni-grid
			:column="2"
			:showBorder="false"
			:square="false"
			:highlight="false"
		>
			<uni-grid-item v-for="(item, index) in skills" :key="index">
				{{ item }}
			</uni-grid-item>
		</uni-grid>
	</view>
</template>

<script>
export default {
	data() {
		return {
			skills: ['html', 'css', 'javascript', 'vue', 'react', 'angular']
		};
	}
};
</script>

<style scoped></style>
