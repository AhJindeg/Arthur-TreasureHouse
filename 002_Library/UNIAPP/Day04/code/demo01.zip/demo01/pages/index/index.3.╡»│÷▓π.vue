<template>
	<view>
		<!-- upopup 弹出层 -->
		<button type="warn" @click="clickOpen">皮卡丘出来吧!</button>
		<!-- ref 绑定组件   使用 this.$refs.popup.属性|方法 -->
		<uni-popup ref="popup" type="center">
			<view
				style="background-color: white;font-size: 35rpx;padding: 10rpx;"
			>
				<!-- 我是弹出层 -->
				<image src="../../static/025.png" mode=""></image>
			</view>
		</uni-popup>
		<!-- 预置样式  提示  message -->
		<!-- ref 这里的popup 后面覆盖了前面的 不会冲突 -->
		<uni-popup ref="popup" type="message">
			<uni-popup-message
				type="success"
				message="恭喜你,成功了!"
				:duration="2000"
			></uni-popup-message>
		</uni-popup>
		<uni-popup ref="popup" type="share">
		    <uni-popup-share title="分享到" @select="select"></uni-popup-share>
		</uni-popup>
	</view>
</template>

<script>
export default {
	methods: {
		clickOpen() {
			// this.$refs 会把所有的组件中的属性为ref的收集起来
			// .ref绑定名称 就可以获取到这个组件的对象  通过这个对象操作对应的方法和属性即可
			this.$refs.popup.open();
		}
	}
};
</script>

<style scoped></style>
