<template>
	<!-- v-if 判断数据没有加载回来  就不渲染 -->
	<view v-if="data">
		<!-- 发请求  拿数据   存本地  做展示 -->
		<!-- 4.做展示 -->
		<uni-grid
			:column="2"
			:showBorder="false"
			:highlight="false"
			:square="false"
		>
			<uni-grid-item v-for="(item, index) in data.list">
				<view class="item">
					<!-- 图片和角标 -->
					<view>
						<!-- 图片 -->
						<image :src="item.roomSrc"></image>
						<!-- 左下角 -->
						<view>{{ item.nickname }}</view>
						<!-- 右上角 -->
						<view>{{ item.hn }}</view>
					</view>
					<view>{{ item.roomName }}</view>
					<!-- 房间名称 -->
				</view>
			</uni-grid-item>
		</uni-grid>
		<!-- 加载组件 -->
		<uni-load-more :status="status"></uni-load-more>
	</view>
</template>

<script>
export default {
	data() {
		return {
			// 初始化数据
			data: null,
			// 加载状态
			status: 'more'
		};
	},
	// 下拉刷新
	onPullDownRefresh() {
		this.getData()
		uni.stopPullDownRefresh()
	},
	// 触底事件
	onReachBottom() {
		// 触底时 修改加载组件的状态为loading
		this.status = 'loading';
		console.log('到底了,加载数据吧');
		// 获取当前页数和最大页数
		// es6 解构语法  前面的名称 必须是后面数据 this.data中存在key
		const { nowPage, pageCount } = this.data;
		// 判断如果当前页数就是最大页数 后续没有数据了 就退出
		if (nowPage === pageCount) {
			this.status = 'noMore';
			return;
		}
		// 请求翻页  +1 翻页操作
		this.getData(nowPage + 1);
	},
	mounted() {
		this.getData();
	},
	methods: {
		// 再获取一次数据
		getMore() {
			const url = '/douyu/api/room/list?page=2&type=yz';
			uni.request({
				url: url,
				method: 'GET',
				data: {},
				success: res => {
					// 2.拿数据
					console.log(res);
					// 3.存本地
					// 旧数据+新数据
					// console.log(this.data);
					// console.log(res.data.data.list);
					res.data.data.list = [
						...this.data.list,
						...res.data.data.list
					];
					this.data = res.data.data;
				},
				fail: () => {},
				complete: () => {}
			});
		},
		getData(page=1) {
			// const url = 'https://m.douyu.com/api/room/list?page=1&type=yz'
			// 配置proxy代理地址需要修改  添加一个标识头
			// 代理服务捕捉到代理标识后，会进行对应的代理操作
			const url = '/douyu/api/room/list?type=yz';
			// 1.发请求
			uni.request({
				url: url,
				method: 'GET',
				data: {page:page},
				success: res => {
					// 2.拿数据
					console.log(res);
					// 3.存本地
					// this.data = res.data.data;
					// 多获取一次数据调用
					// 如果非第一页数据 就不需要再多加载了
					if(page == 1){
						this.getMore();
					}
					if(page>1){
						res.data.data.list = [...this.data.list,...res.data.data.list]
					}
					this.data = res.data.data
				},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style scoped lang="scss">
.item {
	padding: 10rpx;
	image {
		width: 100%;
		height: 250rpx;
		border-radius: 6rpx;
		display: block;
	}
	> view:first-of-type {
		// 相对
		position: relative;
		> view:first-of-type {
			// 左下角
			// 绝对
			position: absolute;
			left: 0;
			bottom: 0;
			color: white;
			background-color: rgba(0, 0, 0, 0.5);
			border-radius: 6rpx;
			font-size: 0.9em;
		}
		> view:last-of-type {
			// 右上角
			// 绝对
			position: absolute;
			right: 0;
			top: 0;
			color: white;
			background-color: rgba(0, 0, 0, 0.5);
			border-radius: 6rpx;
			font-size: 0.9em;
		}
	}
	> view:last-of-type {
		font-size: 1.2em;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
}
</style>
